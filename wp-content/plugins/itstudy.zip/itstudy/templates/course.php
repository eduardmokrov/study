<?php
/**
 * template for siplaying courses
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

get_header();
echo 'course_page';
get_footer();

